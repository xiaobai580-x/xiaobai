#!/system/bin/sh
#初始化区
D="/data/小白"
mkdir -p "$D"

#识别区
R=""
[ -d /data/adb/magisk ] && R="$R Magisk"
[ -d /data/adb/ksu ] && R="$R KernelSU"
[ -d /data/adb/ap ] && R="$R APatch"
set -- $R
case $# in
    1) DETECTED="$1"; echo "Root管理器：$DETECTED" ;;
    0) echo "Root管理器识别失败"; rm -rf "$D"; exit 1 ;;
    *) echo "发现多个工具路径，请清理adb目录内残留Root管理器工作文件"; rm -rf "$D"; exit 1 ;;
esac

#BL状态检测
v() {
    printf '%s\n' "$1" | grep -oE "$2[[:space:]]*=[[:space:]]*\"?[-A-Za-z0-9._]+" 2>/dev/null | head -n 1 | sed 's/.*=[[:space:]]*"*//'
}
c() {
    case "$1" in
        orange|unverified|unlocked|0) echo U ;;
        green|yellow|verified|selfsigned|locked|1) echo L ;;
        *) echo '?' ;;
    esac
}
U=0; L=0; X=0
for S in "$(cat /proc/bootconfig 2>/dev/null)" "$(cat /proc/cmdline 2>/dev/null)"; do
    for K in androidboot.verifiedbootstate androidboot.flash.locked androidboot.vbmeta.device_state; do
        V=$(v "$S" "$K")
        [ -n "$V" ] || continue
        case "$K:$V" in
            androidboot.verifiedbootstate:*) Q=$(c "$V") ;;
            androidboot.flash.locked:*) Q=$(c "$V") ;;
            androidboot.vbmeta.device_state:*) Q=$(c "$V") ;;
        esac
        [ "$Q" = U ] && U=1
        [ "$Q" = L ] && L=1
        [ "$Q" = '?' ] && [ "$V" = red -o "$V" = failed ] && X=1
    done
done
for K in ro.boot.verifiedbootstate ro.boot.flash.locked ro.boot.vbmeta.device_state; do
    V=$(getprop "$K" 2>/dev/null)
    [ -n "$V" ] || continue
    Q=$(c "$V")
    [ "$Q" = U ] && U=1
    [ "$Q" = L ] && L=1
    [ "$V" = red -o "$V" = failed ] && X=1
done
if [ "$X" -eq 0 ] && [ "$U" -eq 1 ] && [ "$L" -eq 0 ]; then
    BL="解锁"
elif [ "$X" -eq 0 ] && [ "$L" -eq 1 ] && [ "$U" -eq 0 ]; then
    BL="伪回锁"
else
    echo "BL状态无法确定，请手动选择"
    echo "BL已解锁（音量键上选择）"
    echo "BL未解锁（音量键下选择）"
    while true; do
        K=$(getevent -qlc 1 2>/dev/null | awk '$4=="DOWN"||$4=="00000001"{print $3}')
        case "$K" in
            KEY_VOLUMEUP) BL="解锁"; break ;;
            KEY_VOLUMEDOWN) BL="伪回锁"; break ;;
        esac
    done
fi
if [ "$DETECTED" = "KernelSU" ] && /data/adb/ksu/bin/ksud debug info 2>/dev/null | grep -q "late_load.*true"; then
    BL="越狱"
fi
echo "工作状态：$BL"

#模块安装函数
m() {
    [ -f "$1" ] || return
    n=$(basename "$1")
    echo "正在安装${n}模块"
    if [ "$DETECTED" = "APatch" ]; then
        /data/adb/ap/bin/apd module install "$1"
    elif [ "$DETECTED" = "KernelSU" ]; then
        /data/adb/ksu/bin/ksud module install "$1"
    else
        su -c "magisk --install-module $1" 2>/dev/null
    fi && echo "${n}模块安装成功" || echo "${n}模块安装失败"
}

#下载区
echo "正在解析下载链接..."
echo "正在解析GitHub加速链接"
P="https://gh-proxy.com/"
A="https://api.github.com/repos/xiaobai580-x/xiaobai/contents/"
J=$(wget -qO- --timeout=15 "$A" 2>/dev/null)
[ -n "$J" ] || J=$(wget -qO- --timeout=15 "${P}${A}" 2>/dev/null)
F=$(echo "$J" | tr -d '\r\n' | grep -o '{[^}]*"download_url"[^}]*}' | while IFS= read -r i; do
    n=$(echo "$i" | grep -o '"name": *"[^"]*资源[^"]*\.zip"' | head -n1 | sed 's/.*: *"//;s/".*//')
    [ -n "$n" ] || continue
    s=$(echo "$i" | grep -o '"size": *[0-9]*' | head -n1 | sed 's/[^0-9]//g')
    w=$(echo "$i" | grep -o '"download_url": *"[^"]*"' | head -n1 | sed 's/.*: *"//;s/".*//')
    w=$(printf '%s' "$w" | sed 's/资源/%E8%B5%84%E6%BA%90/g')
    [ -n "$w" ] && echo "${P}${w}|$n|$s"
done)
[ -z "$F" ] && echo "链接解析失败" && rm -rf "$D" && exit 1
echo "正在下载"

h() {
    s=${1:-0}
    if [ "$s" -ge 1048576 ]; then
        echo "$((s/1048576)).$(((s%1048576)*10/1048576))mb"
    elif [ "$s" -ge 1024 ]; then
        echo "$((s/1024)).$(((s%1024)*10/1024))kb"
    else
        echo "${s}b"
    fi
}
echo "$F" | while IFS='|' read -r u n s; do
    rm -f "$D/$n"
    total=${s:-0}
    wget -q --timeout=30 -O "$D/$n" "$u" &
    wp=$!
    prev=0
    while kill -0 $wp 2>/dev/null; do
        sleep 1
        cur=$(wc -c < "$D/$n" 2>/dev/null)
        cur=${cur:-0}
        [ "$cur" -lt "$prev" ] && prev=$cur
        echo "[$(h "$cur") $(h "$total")] $(h $((cur-prev)))/s"
        prev=$cur
    done
    wait $wp
    [ -s "$D/$n" ] || rm -f "$D/$n"
done
echo "下载完毕"

#解压区
Z=""
for z in "$D"/*.zip; do
    [ -f "$z" ] && { Z="$z"; break; }
done
[ -n "$Z" ] && unzip -o "$Z" -d "$D" >/dev/null 2>&1

#APK安装函数
a() {
    [ -f "$1" ] || return
    n=$(basename "$1")
    echo "正在安装${n}软件"
    chmod 777 "$1" && pm install -r "$1" >/dev/null 2>&1 && echo "${n}软件安装成功" || echo "${n}软件安装失败"
}
#脚本执行函数
s() {
    [ -f "$1" ] || return
    chmod 777 "$1" && MODPATH="$MODPATH" "$1"
}

#模块部署区
for x in modules:m apks:a; do
    d=${x%:*}; r=${x#*:}
    for g in "" "$BL" "$DETECTED" "$DETECTED/$BL"; do
        for f in "$D/$d/$g"/*; do "$r" "$f"; done
    done
done

#补丁部署区
find "$D/patches" -type f 2>/dev/null | while read -r f; do
    n=${f#"$D/patches/"}
    t="/$n"
    mkdir -p "$(dirname "$t")"
    cp -f "$f" "$t" 2>/dev/null && chmod 777 "$t" 2>/dev/null
done

#脚本执行区
for g in "" "$BL" "$DETECTED" "$DETECTED/$BL"; do
    for f in "$D/scripts/$g"/*; do s "$f"; done
done

#收尾区
rm -rf "$D"
echo "安装完成"

#SELinux隐藏区
if [ "$DETECTED" = "KernelSU" ]; then
    echo "正在开启隐藏SELinux修改"
    if /data/adb/ksu/bin/ksud feature set selinux_hide 1 >/dev/null 2>&1; then
        echo "开启成功"
    else
        echo "开启失败"
    fi
fi
# APatch SELinux隐藏功能已移除

#软重启区
if [ "$BL" = "越狱" ]; then
    /data/adb/ksu/bin/ksud soft-reboot
fi
exit 0
