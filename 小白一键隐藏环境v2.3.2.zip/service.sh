#!/system/bin/sh

rm -rf "$(dirname "$0")"