#!/system/bin/sh
echo "正在设置安全日期"
printf 'system=\nboot=%s\nvendor=%s\n' "$(getprop ro.build.version.security_patch)" "$(getprop ro.vendor.build.security_patch)" > /data/adb/tricky_store/security_patch.txt && echo "安全日期设置成功"
echo "正在去除刷机属性"
setprop persist.adb.nonblocking_ffs ""
setprop persist.logd.size ""
setprop persist.logd.size.crash ""
setprop persist.logd.size.system ""
setprop persist.logd.size.main ""
echo "去除成功"
echo ""
echo "正在检查内部储存是否有异常文件"
c=0
for dir in /sdcard /data/local/tmp; do
    for f in "$dir"/*.sh "$dir"/*.img "$dir"/*.xml "$dir"/*.json; do
        [ -f "$f" ] || continue
        echo "发现 $f"
        mv -f "$f" "$dir/.$(basename "$f")"
        c=$((c+1))
    done
done
[ -d "/sdcard/sh" ] && echo "发现 /sdcard/sh" && mv -f "/sdcard/sh" "/sdcard/.sh" && c=$((c+1))
echo ""
echo "成功解决${c}个异常文件"
echo ""
echo "正在删除可疑报包名"
for d in /storage/emulated/0/Android/data/*; do
    [ -d "$d" ] || continue
    s=$(du -sk "$d" 2>/dev/null | cut -f1)
    [ -z "$s" ] && s=0
    if [ "$s" -lt 20 ]; then
        perm=$(stat -c %a "$d" 2>/dev/null)
        if [ "$perm" = "2770" ]; then
            rm -rf "$d" 2>/dev/null
            echo "删除成功 $d"
        fi
    fi
done
echo ""
echo "正在调整MT设置"
for p in /data/user/0/bin.mt.plus.canary/shared_prefs/bin.mt.plus.canary_preferences.xml /data/user/0/bin.mt.plus/shared_prefs/bin.mt.plus_preferences.xml; do
    [ ! -f "$p" ] && continue
    t="${p}.tmp"
    cp "$p" "$t"
    for k in generate_backup_file enable_recycle_bin deletion_warning; do
        if grep -q "name=\"$k\"" "$t"; then
            sed -i "s|<boolean name=\"$k\" value=\"[^\"]*\" />|<boolean name=\"$k\" value=\"false\" />|g" "$t"
        else
            sed -i "s|</map>|    <boolean name=\"$k\" value=\"false\" />\n</map>|" "$t"
        fi
    done
    if grep -q "name=\"mt2_path\"" "$t"; then
        sed -i "s|<string name=\"mt2_path\">.*</string>|<string name=\"mt2_path\">/data/adb</string>|g" "$t"
    else
        sed -i "s|</map>|    <string name=\"mt2_path\">/data/adb</string>\n</map>|" "$t"
    fi
    mv "$t" "$p"
    chmod 777 "$p"
done
echo "MT设置调整完成"
echo ""
echo "正在删除MT2路径"
killall -9 bin.mt.plus.canary bin.mt.plus 2>/dev/null
rm -rf /sdcard/MT2
echo "MT2路径删除成功"