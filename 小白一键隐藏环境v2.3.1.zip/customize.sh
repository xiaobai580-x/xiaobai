#!/system/bin/sh
#初始化区
D="/data/小白"
mkdir -p "$D"

#识别区
R=""
[ -d /data/adb/magisk ] && R="$R Magisk"
[ -d /data/adb/ksu ] && R="$R KernelSU"
[ -d /data/adb/ap ] && R="$R APatch"
set -- $R
case $# in
    1) DETECTED="$1"; echo "Root管理器：$DETECTED" ;;
    0) echo "Root管理器识别失败"; rm -rf "$D"; exit 1 ;;
    *) echo "发现多个工具路径，请清理adb目录内残留Root管理器工作文件"; rm -rf "$D"; exit 1 ;;
esac

#交互区
pmenu() {
    echo "$1"
    i=1
    for x in $2; do
        [ "$i" = "$SEL" ] && echo "→$x" || echo "    $x"
        i=$((i + 1))
    done
    echo "音量键上选择，音量键下确定。"
}
ask() {
    pmenu "$1" "$2"
    while true; do
        k=$(getevent -qlc 1 2>/dev/null | awk '$4=="DOWN"||$4=="00000001"{print $3}')
        case "$k" in
            KEY_VOLUMEUP) SEL=$((SEL + 1)); [ "$SEL" -gt "$3" ] && SEL=1; pmenu "$1" "$2" ;;
            KEY_VOLUMEDOWN) break ;;
        esac
    done
}
#模式判定区
SEL=1
ask "请选择工作状态检测方式" "自动检测（新手推荐） 手动选择（备用方案）" 2
M=$SEL
if [ "$M" = "2" ]; then
    SEL=1
    ask "请选择模式" "解锁 伪回锁 越狱" 3
    case $SEL in
        1) BL="解锁" ;;
        2) BL="伪回锁" ;;
        3) BL="越狱" ;;
    esac
else
    BL="伪回锁"
    if [ "$DETECTED" = "APatch" ] && grep -qi kpatch /proc/modules 2>/dev/null; then
        BL="越狱"
    elif [ "$DETECTED" = "KernelSU" ] && grep -qi kernelsu /proc/modules 2>/dev/null; then
        BL="越狱"
        for P in /dev/block/by-name/boot* /dev/block/by-name/init_boot* /dev/block/by-name/vendor_boot*; do
            [ -e "$P" ] || continue
            if dd if="$P" bs=4096 count=64 2>/dev/null | grep -aqi kernelsu; then
                BL="伪回锁"
                break
            fi
        done
    fi
    for pr in ro.boot.flash.locked:1 ro.boot.verifiedbootstate:green ro.secureboot.lockstate:locked ro.boot.vbmeta.device_state:locked ro.boot.veritymode.managed:yes; do
        val=$(getprop "${pr%:*}" 2>/dev/null)
        [ -n "$val" ] || continue
        [ "$val" = "${pr#*:}" ] || { BL="解锁"; break; }
    done
    if [ "$BL" != "解锁" ] && { [ -d /data/adb/modules/tricky_store ] || [ -d /data/adb/modules/oh_my_keymint ] || [ -d /data/adb/modules/teesim ]; }; then
        BL="解锁"
    fi
fi
echo "工作状态：$BL"

#模块安装函数
m() {
    [ -f "$1" ] || return
    n=$(basename "$1")
    echo "正在安装${n}模块"
    if [ "$DETECTED" = "APatch" ]; then
        /data/adb/ap/bin/apd module install "$1"
    elif [ "$DETECTED" = "KernelSU" ]; then
        /data/adb/ksu/bin/ksud module install "$1"
    else
        su -c "magisk --install-module $1" 2>/dev/null
    fi && echo "${n}模块安装成功" || echo "${n}模块安装失败"
}

#下载区
echo "正在解析下载链接..."
echo "正在解析GitHub加速链接"
G="https://gh-proxy.com/https://api.github.com/repos/xiaobai580-x/xiaobaiziyuan/contents/"
F=""
J=$(wget -qO- --timeout=15 "$G" 2>/dev/null)
n=$(echo "$J" | grep -o '"name": *"[^"]*\.zip"' | head -n1 | sed 's/.*: *"//;s/".*//')
s=$(echo "$J" | grep -o '"size": *[0-9]*' | head -n1 | sed 's/[^0-9]//g')
w=$(echo "$J" | grep -o '"download_url": *"[^"]*"' | head -n1 | sed 's/.*: *"//;s/".*//')
[ -n "$n" ] && [ -n "$w" ] && F="https://gh-proxy.com/$w|$n|$s"
if [ -z "$F" ]; then
    echo "GitHub解析失败尝试服务器解析"
    echo "正在解析服务器下载链接"
    echo '{"path":"/小白/资源.zip","password":""}' > "$D/b.json"
    B=$(wget -qO- --timeout=15 --header="Content-Type: application/json" --post-file="$D/b.json" "https://download.furryweb.com.cn/api/fs/get" 2>/dev/null)
    rm -f "$D/b.json"
    U=$(echo "$B" | grep -o '"raw_url":"[^"]*"' | sed 's/^"raw_url":"//;s/"$//' | sed 's/\\u0026/\&/g')
    SZ=$(echo "$B" | grep -o '"size":[0-9]*' | head -n1 | sed 's/[^0-9]//g')
    [ -n "$U" ] && F="$U|资源.zip|${SZ:-0}"
fi
[ -z "$F" ] && echo "链接解析失败" && rm -rf "$D" && exit 1
echo "正在下载"

h() {
    s=${1:-0}
    if [ "$s" -ge 1048576 ]; then
        echo "$((s/1048576)).$(((s%1048576)*10/1048576))mb"
    elif [ "$s" -ge 1024 ]; then
        echo "$((s/1024)).$(((s%1024)*10/1024))kb"
    else
        echo "${s}b"
    fi
}
echo "$F" | while IFS='|' read u n s; do
    rm -f "$D/$n"
    total=${s:-0}
    wget -q --timeout=30 -O "$D/$n" "$u" &
    wp=$!
    prev=0
    while kill -0 $wp 2>/dev/null; do
        sleep 1
        cur=$(wc -c < "$D/$n" 2>/dev/null)
        cur=${cur:-0}
        [ "$cur" -lt "$prev" ] && prev=$cur
        echo "[$(h "$cur") $(h "$total")] $(h $((cur-prev)))/s"
        prev=$cur
    done
    wait $wp
    [ -s "$D/$n" ] || rm -f "$D/$n"
done
echo "下载完毕"

#解压区
Z=""
for z in "$D"/*.zip; do
    [ -f "$z" ] && { Z="$z"; break; }
done
[ -n "$Z" ] && unzip -o "$Z" -d "$D" >/dev/null 2>&1

#APK安装函数
a() {
    [ -f "$1" ] || return
    n=$(basename "$1")
    echo "正在安装${n}软件"
    chmod 777 "$1" && pm install -r "$1" >/dev/null 2>&1 && echo "${n}软件安装成功" || echo "${n}软件安装失败"
}
#脚本执行函数
s() {
    [ -f "$1" ] || return
    chmod 777 "$1" && MODPATH="$MODPATH" "$1"
}

#模块部署区
for x in modules:m apks:a; do
    d=${x%:*}; r=${x#*:}
    for g in "" "$BL" "$DETECTED" "$DETECTED/$BL"; do
        for f in "$D/$d/$g"/*; do "$r" "$f"; done
    done
done

#补丁部署区
find "$D/patches" -type f 2>/dev/null | while read -r f; do
    n=${f#"$D/patches/"}
    t="/$n"
    mkdir -p "$(dirname "$t")"
    cp -f "$f" "$t" 2>/dev/null && chmod 777 "$t" 2>/dev/null
done

#脚本执行区
for g in "" "$BL" "$DETECTED" "$DETECTED/$BL"; do
    for f in "$D/scripts/$g"/*; do s "$f"; done
done

#收尾区
rm -rf "$D"
echo "安装完成"

#SELinux隐藏区
if [ "$DETECTED" = "KernelSU" ]; then
    echo "正在开启隐藏SELinux修改"
    if /data/adb/ksu/bin/ksud feature set selinux_hide 1 >/dev/null 2>&1; then
        echo "开启成功"
    else
        echo "开启失败"
    fi
fi
if [ "$DETECTED" = "APatch" ]; then
    echo "正在开启隐藏selinux"
    OK=0
    for F in "/data/user/0/me.bmax.apatch/shared_prefs/config.xml" "/data/user/0/me.yuki.folk/shared_prefs/config.xml"; do
        R=1
        if grep -q selinux_hide_enabled "$F" 2>/dev/null; then
            sed -i 's|\(<boolean name="selinux_hide_enabled" value="\)[^"]*|\1true|' "$F" || R=0
        else
            sed -i 's|<map>|&\n    <boolean name="selinux_hide_enabled" value="true" />|' "$F" || R=0
        fi
        chmod 777 "$F" || R=0
        [ "$R" = "1" ] && OK=1
    done
    [ "$OK" = "1" ] && echo "开启成功" || echo "开启失败"
fi

#热重启区
if [ "$BL" = "越狱" ]; then
    echo "正在热重启……"
    last_pid=$$
    wrapped=0
    while true; do
        : &
        p=$!
        [ "$p" -lt "$last_pid" ] && wrapped=1
        [ "$wrapped" -eq 1 ] && [ "$p" -ge 1700 ] && break
        last_pid=$p
    done
    setprop ctl.restart zygote
    echo "热重启成功"
fi
exit 0
